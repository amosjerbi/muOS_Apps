#!/bin/sh
# HELP: How Long to Beat
# ICON: retroarch
# GRID: RetroArch

# Source muOS functions if available
if [ -f /opt/muos/script/var/func.sh ]; then
    . /opt/muos/script/var/func.sh
else
    echo "Warning: muOS functions not found"
fi

# Signal that we're launching an app
echo app >/tmp/act_go

# Set up SDL scaler if available
if type GET_VAR >/dev/null 2>&1; then
    SDL_HQ_SCALER="$(GET_VAR "device" "sdl/scaler")"
    export SDL_HQ_SCALER
fi

# Get the application directory
APP_DIR="$(dirname "$0")"
cd "$APP_DIR" || exit 1

# Set foreground process if available
if type SET_VAR >/dev/null 2>&1; then
    SET_VAR "system" "foreground_process" "howlongtobeat"
fi

# Create a log file for debugging
LOG_FILE="$APP_DIR/howlongtobeat.log"
echo "Starting How Long to Beat at $(date)" > "$LOG_FILE"

# Make sure Python scripts are executable
chmod 755 ./game_search_main.py
chmod 755 ./game_search_main.py
chmod 755 ./test_game_search.py
chmod 755 ./install_dependencies.sh

# Check if dependencies are installed, if not install them
if [ ! -f "$APP_DIR/.dependencies_installed" ]; then
    echo "Installing dependencies..." >> "$LOG_FILE"
    # Display a message to the user
    echo "First-time setup: Installing required dependencies..."
    echo "This includes PIL and HowLongToBeat API..."
    echo "This will only happen once. Please wait..."
    
    # Run the dependency installation script
    ./install_dependencies.sh >> "$LOG_FILE" 2>&1
    
    # Mark dependencies as installed
    touch "$APP_DIR/.dependencies_installed"
    
    echo "Dependencies installed successfully!" >> "$LOG_FILE"
    echo "Setup complete! Starting How Long to Beat..."
    sleep 2
fi

# Check if PIL is available
python3 -c "import PIL; print('PIL is available')" >> "$LOG_FILE" 2>&1 || {
    echo "Error: PIL not available" >> "$LOG_FILE"
    # Try to reinstall PIL
    echo "Attempting to reinstall PIL..." >> "$LOG_FILE"
    ./install_dependencies.sh >> "$LOG_FILE" 2>&1
    
    # Check again
    python3 -c "import PIL; print('PIL is now available')" >> "$LOG_FILE" 2>&1 || {
        echo "Error: PIL installation failed" >> "$LOG_FILE"
        # Display error message
        echo "Error: Python Imaging Library (PIL) could not be installed"
        echo "How Long to Beat requires PIL to run."
        echo "Please check the log file: $LOG_FILE"
        sleep 5
        exit 1
    }
}

# Check if howlongtobeatpy is available (required)
python3 -c "import howlongtobeatpy; print('HowLongToBeat API is available')" >> "$LOG_FILE" 2>&1 || {
    echo "Error: HowLongToBeat API not available - This is required!" >> "$LOG_FILE"
    echo "Error: HowLongToBeat API library not installed"
    echo "Please run: pip install howlongtobeatpy"
    echo "Or run ./install_dependencies.sh"
    sleep 5
    exit 1
}

# Launch the How Long to Beat application
echo "Launching game_search_main.py" >> "$LOG_FILE"
python3 game_search_main.py 2>> "$LOG_FILE"

# Clean up
if [ -n "$SDL_HQ_SCALER" ]; then
    unset SDL_HQ_SCALER
fi

# Reset screen resolution if muOS functions are available
if type GET_VAR >/dev/null 2>&1 && type FB_SWITCH >/dev/null 2>&1; then
    [ "$(GET_VAR "global" "settings/hdmi/enabled")" -eq 1 ] && SCREEN_TYPE="external" || SCREEN_TYPE="internal"
    FB_SWITCH "$(GET_VAR "device" "screen/$SCREEN_TYPE/width")" "$(GET_VAR "device" "screen/$SCREEN_TYPE/height")" 32
fi

exit 0

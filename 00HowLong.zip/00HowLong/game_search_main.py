import game_search as app
import sys
import traceback
import graphic

def main():
    try:
        app.start()

        while True:
            try:
                result = app.update()
                if result == "exit":
                    print("Game search exiting...")
                    break
            except Exception as e:
                print(f"Error in app.update(): {str(e)}")
                traceback.print_exc()
                # Don't exit, continue running
                continue
    except Exception as e:
        print(f"Fatal error: {str(e)}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExiting gracefully...")
        # Set resolution to 720x480 before exiting
        graphic.set_resolution_720x480()
        sys.exit(0)
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        traceback.print_exc()
        # Set resolution to 720x480 even when exiting due to error
        try:
            graphic.set_resolution_720x480()
        except:
            pass  # Don't let resolution setting errors prevent exit
        sys.exit(1) 
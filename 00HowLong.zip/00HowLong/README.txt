WiFi Manager for muOS
====================

This application allows you to manage WiFi connections directly on your muOS device.

Installation Instructions:
-------------------------
1. Extract the application files to your muOS device
   - The application should be installed in /mnt/mmc/MUOS/application/WiFi_Manager

2. The application should now appear in your muOS application menu
   - Look for "WiFi Manager" in the applications list

First Launch:
-----------
The first time you launch the application, it will automatically check and install any required dependencies.
This process will only happen once and may take a few moments to complete.

Features:
--------
- View all saved WiFi networks from wpa_supplicant.conf
- See current WiFi connection status
- Connect to saved networks with priority ordering
- Real-time connection feedback
- Network priority display
- Refresh network list
- Auto-connect toggle (enable/disable automatic WiFi connection)
- Auto-connect status display (shows if auto-connect is ON/OFF)

Controls:
--------
In the main WiFi screen:
- Up/Down: Navigate between saved WiFi networks
- A: Connect to selected network
- B: Refresh network list
- X: Edit selected network
- Y: Add new network
- L1: Delete selected network
- R1: Toggle auto-connect (enable/disable automatic WiFi connection)
- M: Exit application

WiFi Configuration:
------------------
The WiFi Manager reads network configurations from /etc/wpa_supplicant.conf

Example wpa_supplicant.conf format:
```
network={
    ssid="YourNetworkName"
    scan_ssid=1
    psk="YourPassword"
    priority=5
}

network={
    ssid="AnotherNetwork"
    scan_ssid=1
    psk="AnotherPassword"
    priority=3
}
```

Higher priority numbers are preferred for automatic connection.

Auto-Connect Feature:
--------------------
The WiFi Manager includes an auto-connect feature that automatically connects to available WiFi networks based on priority:

- **Auto-Connect Status**: Displayed on the main screen as "Auto-Connect: ON/OFF"
- **Toggle Control**: Press R1 to enable/disable auto-connect
- **Priority-Based**: When enabled, automatically connects to the highest priority network available
- **Background Operation**: Runs as a system daemon (wpa_supplicant) in the background
- **Automatic Switching**: Switches to higher priority networks when they become available

When auto-connect is enabled:
- The system automatically scans for available networks
- Connects to the highest priority network in range
- Maintains connection and reconnects if disconnected
- Switches to higher priority networks when they become available

System Requirements:
------------------
- Python 3 with PIL (Pillow) for graphics
- iwconfig (wireless-tools) for WiFi status checking
- wpa_supplicant for WiFi connection management
- Access to /etc/wpa_supplicant.conf

Troubleshooting:
--------------
If you encounter any issues:

1. Check the log file
   - Look at the file /mnt/mmc/MUOS/application/WiFi_Manager/wifimanager.log
   - This file contains information about what happened when the application tried to start

2. Manual dependency installation:
   If the automatic installation fails, you can manually install the dependencies:
   ```
   cd /mnt/mmc/MUOS/application/WiFi_Manager
   ./install_dependencies.sh
   ```

3. WiFi configuration issues:
   - Ensure /etc/wpa_supplicant.conf exists and is readable
   - Check that network blocks are properly formatted
   - Verify WiFi passwords are correct

4. Permission issues:
   - Make sure all files in the application directory are executable
   ```
   chmod -R +x /mnt/mmc/MUOS/application/WiFi_Manager
   ```

5. Manual launch:
   - To launch the application manually and see any error messages:
   ```
   cd /mnt/mmc/MUOS/application/WiFi_Manager
   ./mux_launch.sh
   ```

Network Status Indicators:
-------------------------
- Green dot (●): Currently connected network
- "Connected: [Network Name]": Shows active connection
- "Not connected": No active WiFi connection
- Priority numbers: Higher values are preferred

Enjoy your WiFi Manager!

def handle_keyboard_input():

import graphic as gr
from graphic import set_resolution_720x480
import input
import sys
import time
import os
import atexit
import signal
import threading
import re

# Import HowLongToBeat API
try:
    from howlongtobeatpy import HowLongToBeat
    HLTB_AVAILABLE = True
except ImportError:
    HLTB_AVAILABLE = False
    print("WARNING: howlongtobeatpy not available. Game search disabled.")

# Global flag to prevent duplicate exit handling
_exit_handler_called = False

# Exit handler to ensure resolution is reset on exit
def exit_handler():
    global _exit_handler_called
    if _exit_handler_called:
        return
    _exit_handler_called = True
    
    print("Exiting Game Search, resetting resolution to 720x480...")
    try:
        set_resolution_720x480()
        gr.draw_end()
    except Exception as e:
        print(f"Error in exit handler: {str(e)}")

# Signal handler for graceful termination
def signal_handler(sig, frame):
    print(f"Received signal {sig}, exiting gracefully...")
    exit_handler()
    sys.exit(0)

# Register the exit handler
atexit.register(exit_handler)

# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Global variables
selected_position = 0
current_window = "menu"  # Start with menu instead of keyboard
max_elem = 11
skip_input_check = False
search_results = []
search_feedback = ""
feedback_timer = 0
searching = False

# Menu system variables
menu_options = ["Search Games by Keyboard", "Scan ROM Collection"]
menu_selected = 0

# Auto-repeat variables for keyboard navigation
auto_repeat_timer = 0
auto_repeat_delay = 10  # Initial delay before auto-repeat starts (10 frames = 0.5 seconds)
auto_repeat_rate = 3    # Auto-repeat interval (3 frames = 0.15 seconds)
current_held_direction = None
last_direction_state = {"up": False, "down": False, "left": False, "right": False}

# ROM scanning variables
rom_scan_results = []
rom_scan_progress = 0
rom_scan_total = 0
rom_scan_current = ""
scanning_roms = False

# Virtual keyboard for game search (no special keys needed)
virtual_keyboard = [
    ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
    ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
    ["a", "s", "d", "f", "g", "h", "j", "k", "l", "-"],
    ["z", "x", "c", "v", "b", "n", "m", "_", ".", " "]
]
keyboard_position = [0, 0]
search_query = ""
selected_game = None

class GameSearchManager:
    def __init__(self):
        self.hltb = HowLongToBeat() if HLTB_AVAILABLE else None
        self.search_results = []
        self.current_search = ""
        
    def search_games(self, query):
        """Search for games using HowLongToBeat API"""
        if not self.hltb:
            return []
            
        try:
            # Use synchronous search for simplicity in this environment
            results = self.hltb.search(query)
            if results:
                # Sort by similarity and take top 50 results
                sorted_results = sorted(results, key=lambda x: x.similarity, reverse=True)
                return sorted_results[:50]
            return []
        except Exception as e:
            print(f"Error searching games: {e}")
            return []
    
    def format_time(self, hours):
        """Format hours into readable time format"""
        if hours is None or hours == 0:
            return "N/A"
        
        if hours < 1:
            minutes = int(hours * 60)
            return f"{minutes}m"
        elif hours < 24:
            return f"{hours:.1f}h"
        else:
            days = int(hours // 24)
            remaining_hours = hours % 24
            if remaining_hours > 0:
                return f"{days}d {remaining_hours:.1f}h"
            else:
                return f"{days}d"

class ROMScanner:
    def __init__(self, game_search_manager):
        self.gsm = game_search_manager
        self.rom_extensions = {
            '.nes', '.smc', '.sfc', '.gb', '.gbc', '.gba', '.nds', '.3ds',
            '.z64', '.n64', '.v64', '.zip', '.7z', '.rar', '.bin', '.cue',
            '.iso', '.chd', '.pbp', '.cso', '.wbfs', '.gcm', '.gcz', '.rvz',
            '.wad', '.dol', '.elf', '.xbe', '.img', '.rom', '.md', '.smd',
            '.gen', '.32x', '.gg', '.sms', '.pce', '.sgx', '.lynx', '.ngp',
            '.ngc', '.ws', '.wsc', '.a26', '.a52', '.a78', '.col', '.int',
            '.vec', '.o2', '.5200', '.xex', '.atr', '.d64', '.prg', '.t64'
        }
        
    def clean_rom_name(self, filename):
        """Clean ROM filename to extract likely game name"""
        # Remove file extension
        name = os.path.splitext(filename)[0]
        
        # Remove common ROM indicators in brackets/parentheses
        name = re.sub(r'\([^)]*\)', '', name)
        name = re.sub(r'\[[^\]]*\]', '', name)
        name = re.sub(r'\{[^}]*\}', '', name)
        
        # Remove common suffixes
        suffixes = ['_USA', '_Europe', '_Japan', '_World', '_Rev_A', '_Rev_B', 
                   '_v1.0', '_v1.1', '_Final', '_beta', '_demo', '_trainer']
        for suffix in suffixes:
            if name.upper().endswith(suffix.upper()):
                name = name[:-len(suffix)]
        
        # Replace underscores and dashes with spaces
        name = name.replace('_', ' ').replace('-', ' ')
        
        # Remove extra spaces and trim
        name = ' '.join(name.split())
        
        return name
    
    def scan_roms(self, rom_directory="/mnt/mmc/Roms"):
        """Scan ROM directory and return list of ROM files"""
        rom_files = []
        
        if not os.path.exists(rom_directory):
            print(f"ROM directory not found: {rom_directory}")
            return rom_files
            
        try:
            for root, dirs, files in os.walk(rom_directory):
                for file in files:
                    # Check if file has a ROM extension
                    _, ext = os.path.splitext(file.lower())
                    if ext in self.rom_extensions:
                        full_path = os.path.join(root, file)
                        rom_files.append({
                            'filename': file,
                            'path': full_path,
                            'clean_name': self.clean_rom_name(file),
                            'system': os.path.basename(root) if root != rom_directory else 'Unknown'
                        })
            
            print(f"Found {len(rom_files)} ROM files")
            return rom_files
            
        except Exception as e:
            print(f"Error scanning ROMs: {e}")
            return rom_files
    
    def search_rom_game(self, rom_info):
        """Search for a specific ROM in the game database"""
        clean_name = rom_info['clean_name']
        if not clean_name or len(clean_name) < 2:
            return None
            
        try:
            results = self.gsm.search_games(clean_name)
            if results and len(results) > 0:
                # Return the best match (lowered similarity threshold from 0.5 to 0.3)
                best_match = results[0]
                if best_match.similarity > 0.3:  # Lower threshold for better matching
                    print(f"Found match for '{clean_name}': {best_match.game_name} ({best_match.similarity:.1%})")
                    return {
                        'rom_info': rom_info,
                        'game_data': best_match,
                        'match_confidence': best_match.similarity
                    }
                else:
                    print(f"Match for '{clean_name}' too low: {best_match.similarity:.1%}")
            else:
                print(f"No results found for '{clean_name}'")
            return None
        except Exception as e:
            print(f"Error searching for {clean_name}: {e}")
            return None

game_search_manager = GameSearchManager()
rom_scanner = ROMScanner(game_search_manager)

def start():
    gr.draw_start()
    load_menu_screen()

def update():
    try:
        global current_window, skip_input_check, feedback_timer, searching

        if skip_input_check:
            input.reset_input()
            skip_input_check = False
        else:
            input.check()

        # Decrease feedback timer
        if feedback_timer > 0:
            feedback_timer -= 1

        # Debug: Print current window state periodically
        current_time = int(time.time())
        if current_time % 5 == 0:  # Every 5 seconds
            print(f"DEBUG: Current window: {current_window}, ROM results: {len(rom_scan_results) if rom_scan_results else 0}")

        # Exit handling
        if input.key("MENUF") or input.codeName == "M" or input.codeName == "312":
            print("Exit button pressed, returning to main menu...")
            exit_handler()
            return "exit"

        # Window-specific input handling
        if current_window == "menu":
            handle_menu_input()
        elif current_window == "keyboard":
            handle_keyboard_input()
        elif current_window == "results":
            handle_results_input()
        elif current_window == "details":
            handle_details_input()
        elif current_window == "searching":
            # Just display searching screen, no input needed
            pass
        elif current_window == "rom_scan":
            print("DEBUG: In rom_scan window, handling input")
            handle_rom_scan_input()
        elif current_window == "rom_scanning":
            # Just display scanning progress, no input needed
            pass

        # Refresh the display
        if current_window == "menu":
            load_menu_screen()
        elif current_window == "keyboard":
            load_keyboard_screen()
        elif current_window == "results":
            load_results_screen()
        elif current_window == "details":
            load_details_screen()
        elif current_window == "searching":
            load_searching_screen()
        elif current_window == "rom_scan":
            print("DEBUG: Loading ROM scan screen")
            load_rom_scan_screen()
        elif current_window == "rom_scanning":
            load_rom_scanning_screen()

        gr.draw_paint()
        time.sleep(0.05)  # 50ms delay for smooth operation

    except Exception as e:
        print(f"Error in game search update: {str(e)}")
        return "error"

def handle_menu_input():
    global menu_selected, current_window, skip_input_check

    if input.key("DY", -1):  # Up
        if menu_selected > 0:
            menu_selected -= 1
        skip_input_check = True
    elif input.key("DY", 1):  # Down
        if menu_selected < len(menu_options) - 1:
            menu_selected += 1
        skip_input_check = True
    elif input.key("A"):  # Select option
        if menu_selected == 0:
            current_window = "keyboard"
        elif menu_selected == 1:
            current_window = "rom_scanning"
            # Perform ROM scan synchronously
            perform_rom_scan_sync()
        skip_input_check = True
    elif input.key("B"):  # Exit
        exit_handler()
        return "exit"

def handle_keyboard_input():
    global current_window, keyboard_position, search_query, skip_input_check
    global auto_repeat_timer, current_held_direction, last_direction_state

    # Check current direction states
    current_direction_state = {
        "up": input.key("DY", -1),
        "down": input.key("DY", 1),
        "left": input.key("DX", -1),
        "right": input.key("DX", 1)
    }
    
    # Detect newly pressed directions
    newly_pressed = None
    for direction, pressed in current_direction_state.items():
        if pressed and not last_direction_state[direction]:
            newly_pressed = direction
            break
    
    # Reset auto-repeat if direction changed or released
    if newly_pressed or not any(current_direction_state.values()):
        if newly_pressed:
            current_held_direction = newly_pressed
            auto_repeat_timer = 0
            # Execute immediate movement for newly pressed direction
            move_keyboard_cursor(newly_pressed)
            skip_input_check = True
        else:
            current_held_direction = None
            auto_repeat_timer = 0
    
    # Handle auto-repeat for held directions
    elif current_held_direction and current_direction_state[current_held_direction]:
        auto_repeat_timer += 1
        
        # Start auto-repeat after initial delay, then repeat at regular intervals
        if auto_repeat_timer >= auto_repeat_delay and (auto_repeat_timer - auto_repeat_delay) % auto_repeat_rate == 0:
            move_keyboard_cursor(current_held_direction)
            skip_input_check = True
    
    # Store current state for next frame
    last_direction_state = current_direction_state.copy()
        
    # Handle other inputs (non-directional)
    if input.key("A"):  # Select character
        char = virtual_keyboard[keyboard_position[1]][keyboard_position[0]]
        if len(search_query) < 50:
            search_query += char
        skip_input_check = True
        
    elif input.key("R2"):  # Delete last character
        if search_query:
            search_query = search_query[:-1]
        skip_input_check = True
        
    elif input.key("L2"):  # Clear entire search query
        search_query = ""
        skip_input_check = True
        
    elif input.key("START"):  # Start search
        if search_query.strip():
            current_window = "searching"
            threading.Thread(target=perform_search, args=(search_query.strip(),), daemon=True).start()
        else:
            set_feedback("Enter a game name first!")
        skip_input_check = True
        
    elif input.key("B"):  # Back to menu
        current_window = "menu"
        skip_input_check = True

def move_keyboard_cursor(direction):
    """Move the keyboard cursor in the specified direction with bounds checking"""
    global keyboard_position
    
    if direction == "up":
        if keyboard_position[1] > 0:
            keyboard_position[1] -= 1
    elif direction == "down":
        if keyboard_position[1] < len(virtual_keyboard) - 1:
            keyboard_position[1] += 1
    elif direction == "left":
        if keyboard_position[0] > 0:
            keyboard_position[0] -= 1
    elif direction == "right":
        if keyboard_position[0] < len(virtual_keyboard[keyboard_position[1]]) - 1:
            keyboard_position[0] += 1

def perform_search(query):
    """Perform game search in background thread"""
    global current_window, search_results, search_feedback, feedback_timer
    
    try:
        results = game_search_manager.search_games(query)
        search_results = results
        
        if results:
            current_window = "results"
            global selected_position
            selected_position = 0
        else:
            current_window = "keyboard"
            set_feedback("No games found!")
            
    except Exception as e:
        current_window = "keyboard"
        set_feedback(f"Search error: {str(e)}")

def perform_rom_scan_sync():
    """Perform ROM scanning synchronously to avoid threading issues"""
    global current_window, rom_scan_results, rom_scan_progress, rom_scan_total, rom_scan_current, scanning_roms, selected_position
    
    try:
        print("Starting synchronous ROM scan")
        scanning_roms = True
        rom_scan_results = []
        rom_scan_progress = 0
        
        # Show scanning screen first
        current_window = "rom_scanning"
        
        # First, scan for ROM files
        rom_scan_current = "Scanning ROM directory..."
        rom_files = rom_scanner.scan_roms()
        rom_scan_total = len(rom_files)
        
        print(f"ROM scan started: found {rom_scan_total} ROM files")
        
        if rom_scan_total == 0:
            current_window = "keyboard"
            set_feedback("No ROM files found in /mnt/mmc/Roms")
            scanning_roms = False
            print("No ROM files found, returning to keyboard")
            return
        
        # Search for each ROM in the database
        matches_found = 0
        rom_scan_results.clear()
        
        for i, rom_info in enumerate(rom_files):
            rom_scan_current = f"Searching: {rom_info['clean_name']}"
            rom_scan_progress = i + 1
            
            # Update display during scan
            load_rom_scanning_screen()
            gr.draw_paint()
            
            print(f"Searching for ROM {i+1}/{rom_scan_total}: {rom_info['clean_name']}")
            
            # Search for the game
            match = rom_scanner.search_rom_game(rom_info)
            if match:
                rom_scan_results.append(match)
                matches_found += 1
                print(f"  -> Added to results (total matches: {matches_found})")
        
        print(f"ROM scan completed: {matches_found} matches found out of {rom_scan_total} ROMs")
        print(f"ROM scan results length: {len(rom_scan_results)}")
        
        # Sort results by match confidence
        if rom_scan_results:
            rom_scan_results.sort(key=lambda x: x['match_confidence'], reverse=True)
        
        # Force window transition
        scanning_roms = False
        
        if len(rom_scan_results) > 0:
            print(f"Setting window to rom_scan with {len(rom_scan_results)} results")
            selected_position = 0
            current_window = "rom_scan"
            print(f"Window set to: {current_window}")
        else:
            print("No matches found, staying on keyboard")
            current_window = "keyboard"
            set_feedback(f"Scanned {rom_scan_total} ROMs but found no matches in database!")
        
        print(f"ROM scan sync completed. Window: {current_window}, Results: {len(rom_scan_results)}")
        
    except Exception as e:
        print(f"ROM scan error: {str(e)}")
        import traceback
        traceback.print_exc()
        current_window = "keyboard"
        set_feedback(f"ROM scan error: {str(e)}")
        scanning_roms = False

def handle_rom_scan_input():
    global current_window, selected_position, selected_game, skip_input_check

    if input.key("DY", -1):  # Up
        if selected_position > 0:
            selected_position -= 1
        skip_input_check = True
        
    elif input.key("DY", 1):  # Down
        if selected_position < len(rom_scan_results) - 1:
            selected_position += 1
        skip_input_check = True
        
    elif input.key("A"):  # View game details
        if rom_scan_results and selected_position < len(rom_scan_results):
            selected_game = rom_scan_results[selected_position]['game_data']
            current_window = "details"
        skip_input_check = True
        
    elif input.key("B"):  # Back to menu
        current_window = "menu"
        skip_input_check = True

def handle_results_input():
    global current_window, selected_position, selected_game, skip_input_check

    if input.key("DY", -1):  # Up
        if selected_position > 0:
            selected_position -= 1
        skip_input_check = True
        
    elif input.key("DY", 1):  # Down
        if selected_position < len(search_results) - 1:
            selected_position += 1
        skip_input_check = True
        
    elif input.key("A"):  # View game details
        if search_results and selected_position < len(search_results):
            selected_game = search_results[selected_position]
            current_window = "details"
        skip_input_check = True
        
    elif input.key("B"):  # Back to keyboard
        current_window = "keyboard"
        skip_input_check = True

def handle_details_input():
    global current_window, skip_input_check

    if input.key("B"):  # Back to previous screen
        # Check if we came from ROM scan or regular search results
        if rom_scan_results and selected_game:
            current_window = "rom_scan"
        else:
            current_window = "results"
        skip_input_check = True

def set_feedback(message):
    global search_feedback, feedback_timer
    search_feedback = message
    feedback_timer = 60  # Show for 3 seconds at 20 FPS

def load_keyboard_screen():
    gr.draw_clear()
    
    # Title
    gr.draw_text((50, 30), "Enter Game Name", font=15, color='lightblue')
    
    # Current input
    gr.draw_rectangle([40, 60, 600, 90], fill=gr.colorBlue, outline='white')
    gr.draw_text((50, 70), search_query + "_", font=13, color='lightblue')
    
    # Virtual keyboard
    start_y = 130
    for row_idx, row in enumerate(virtual_keyboard):
        y = start_y + (row_idx * 40)
        for col_idx, key in enumerate(row):
            x = 50 + (col_idx * 55)
            
            # Highlight selected key
            if keyboard_position[1] == row_idx and keyboard_position[0] == col_idx:
                gr.draw_rectangle([x-2, y-2, x+48, y+32], fill=gr.colorBlue, outline='white')
            else:
                gr.draw_rectangle([x-2, y-2, x+48, y+32], fill='gray', outline='lightgray')
            
            gr.draw_text((x+15, y+8), key, font=11, color='lightblue')
    
    # Controls (simplified - no special keys)
    gr.draw_text((50, 320), "Controls:", font=13, color='lightblue')
    gr.draw_text((50, 350), "A - Select character", font=11, color='lightblue')
    gr.draw_text((50, 370), "R2 - Delete last character", font=11, color='lightblue')
    gr.draw_text((50, 390), "L2 - Clear entire search query", font=11, color='lightblue')
    gr.draw_text((50, 410), "START - Search for game", font=11, color='lightblue')
    gr.draw_text((50, 430), "B - Back to menu", font=11, color='lightblue')
    gr.draw_text((50, 450), "D-pad", font=11, color='lightblue')
    
    # Feedback message
    if feedback_timer > 0 and search_feedback:
        gr.draw_rectangle([40, 440, 600, 470], fill='darkblue', outline='blue')
        gr.draw_text((50, 455), search_feedback, font=11, color='lightblue')

def load_searching_screen():
    gr.draw_clear()
    
    # Title
    gr.draw_text((200, 200), "Searching...", font=15, color='lightblue')
    gr.draw_text((180, 240), "Please wait while we search for games", font=11, color='lightblue')
    
    # Simple loading animation
    dots = "." * ((int(time.time() * 2) % 4))
    gr.draw_text((320, 200), dots, font=15, color='lightblue')

def load_results_screen():
    gr.draw_clear()
    
    # Title
    gr.draw_text((50, 30), f"Search Results ({len(search_results)} found)", font=15, color='lightblue')
    
    if not search_results:
        gr.draw_text((50, 100), "No games found. Try a different search term.", font=13, color='lightblue')
        gr.draw_text((50, 400), "B - Back to keyboard", font=11, color='lightblue')
        return
    
    # Display results (scrollable list)
    start_idx = max(0, selected_position - 4)
    end_idx = min(len(search_results), start_idx + 8)
    
    for i in range(start_idx, end_idx):
        game = search_results[i]
        y = 80 + ((i - start_idx) * 55)  # Increased from 40 to 55 for better separation between entries
        
        # Add selection indicator for selected item (no background rectangle)
        text_x = 50
        if i == selected_position:
            gr.draw_text((42, y), ">", font=11, color='white')
            text_x = 60
        
        # Game name and similarity
        game_text = f"{game.game_name} ({game.similarity:.0%})"
        if i == selected_position:
            gr.draw_text((text_x, y), game_text, font=11, color='white')
        else:
            gr.draw_text((text_x, y), game_text, font=11, color='lightblue')
        
        # # Platform info if available
        # if hasattr(game, 'profile_platforms') and game.profile_platforms:
        #     platform_text = f"Platform: {game.profile_platforms[0] if game.profile_platforms else 'Unknown'}"
        #     gr.draw_text((text_x + 20, y + 60), platform_text, font=11, color='lightblue')
    
    # Controls
    gr.draw_text((50, 400), "A - View Details, B - Back to keyboard", font=11, color='lightblue')
    gr.draw_text((50, 420), "D-pad - Navigate", font=11, color='lightblue')

def load_details_screen():
    gr.draw_clear()
    
    if not selected_game:
        gr.draw_text((50, 100), "No game selected", font=13, color='lightblue')
        return
    
    game = selected_game
    
    # Check if this game is from ROM scan and find ROM info
    rom_info = None
    match_confidence = None
    if rom_scan_results:
        for match in rom_scan_results:
            if match['game_data'] == selected_game:
                rom_info = match['rom_info']
                match_confidence = match['match_confidence']
                break
    
    # Game title with ROM indicator
    if rom_info:
        gr.draw_text((50, 30), f"{game.game_name}", font=15, color='lightblue')
        gr.draw_text((50, 55), f"From your ROM: {rom_info['filename']}", font=11, color='lightblue')
        gr.draw_text((50, 75), f"System: {rom_info['system']} | Match: {match_confidence:.0%}", font=11, color='lightblue')
        y_offset = 110
    else:
        gr.draw_text((50, 30), game.game_name, font=15, color='lightblue')
        y_offset = 80
    
    # Game info
    
    # # Platforms
    # if hasattr(game, 'profile_platforms') and game.profile_platforms:
    #     platforms = ", ".join(game.profile_platforms)
    #     gr.draw_text((50, y_offset), f"Platforms: {platforms}", font=11, color='lightblue')
    #     y_offset += 25
    
    # Completion times
    gr.draw_text((50, y_offset), "Completion Times:", font=13, color='lightblue')
    y_offset += 30
    
    # Main story
    if hasattr(game, 'main_story') and game.main_story:
        main_time = game_search_manager.format_time(game.main_story)
        gr.draw_text((70, y_offset), f"Main Story: {main_time}", font=11, color='lightblue')
        y_offset += 25
    
    # Main + Extra
    if hasattr(game, 'main_extra') and game.main_extra:
        extra_time = game_search_manager.format_time(game.main_extra)
        gr.draw_text((70, y_offset), f"Main + Extra: {extra_time}", font=11, color='lightblue')
        y_offset += 25
    
    # Completionist
    if hasattr(game, 'completionist') and game.completionist:
        comp_time = game_search_manager.format_time(game.completionist)
        gr.draw_text((70, y_offset), f"Completionist: {comp_time}", font=11, color='lightblue')
        y_offset += 25
    
    # All styles (if available)
    if hasattr(game, 'all_styles') and game.all_styles:
        all_time = game_search_manager.format_time(game.all_styles)
        gr.draw_text((70, y_offset), f"All Styles: {all_time}", font=11, color='lightblue')
        y_offset += 25
    
    # Game type
    if hasattr(game, 'game_type') and game.game_type:
        gr.draw_text((50, y_offset + 20), f"Type: {game.game_type}", font=11, color='lightblue')
    
    # Controls (different message based on where we came from)
    if rom_info:
        gr.draw_text((50, 420), "B - Back to ROM collection list", font=11, color='lightblue')
    else:
        gr.draw_text((50, 420), "B - Back to search results", font=11, color='lightblue')

def load_rom_scanning_screen():
    gr.draw_clear()
    
    # Title
    gr.draw_text((150, 50), "Scanning ROM Collection", font=15, color='lightblue')
    
    # Progress info
    gr.draw_text((50, 120), rom_scan_current, font=11, color='lightblue')
    
    if rom_scan_total > 0:
        progress_text = f"Progress: {rom_scan_progress}/{rom_scan_total} ({int(rom_scan_progress/rom_scan_total*100)}%)"
        gr.draw_text((50, 150), progress_text, font=11, color='lightblue')
        
        # Progress bar
        bar_width = 500
        bar_height = 20
        progress_width = int((rom_scan_progress / rom_scan_total) * bar_width)
        
        # Background bar
        gr.draw_rectangle([50, 180, 50 + bar_width, 180 + bar_height], fill='darkgray', outline='white')
        
        # Progress bar
        if progress_width > 0:
            gr.draw_rectangle([50, 180, 50 + progress_width, 180 + bar_height], fill='blue', outline='white')
    
    # Instructions
    gr.draw_text((50, 250), "Please wait while we scan your ROM collection", font=11, color='lightblue')
    gr.draw_text((50, 280), "and match games with completion data...", font=11, color='lightblue')

def load_rom_scan_screen():
    gr.draw_clear()
    
    # Title with instructions
    gr.draw_text((50, 30), f"ROM Collection - {len(rom_scan_results)} Games Found", font=15, color='lightblue')
    gr.draw_text((50, 55), "Select a game to view completion data:", font=11, color='lightblue')
    
    if not rom_scan_results:
        gr.draw_text((50, 120), "No matching games found in your ROM collection.", font=13, color='lightblue')
        gr.draw_text((50, 150), "The scanner looked in /mnt/mmc/Roms for ROM files", font=11, color='lightblue')
        gr.draw_text((50, 170), "but couldn't match them with the game database.", font=11, color='lightblue')
        gr.draw_text((50, 400), "B - Back to menu", font=11, color='lightblue')
        return
    
    # Display results (scrollable list) - show more games at once
    start_idx = max(0, selected_position - 4)
    end_idx = min(len(rom_scan_results), start_idx + 8)
    
    # Show scroll indicator if needed
    if len(rom_scan_results) > 8:
        scroll_text = f"({selected_position + 1}/{len(rom_scan_results)}) Use Up/Down to scroll"
        gr.draw_text((400, 55), scroll_text, font=11, color='lightblue')
    
    for i in range(start_idx, end_idx):
        match = rom_scan_results[i]
        rom_info = match['rom_info']
        game_data = match['game_data']
        confidence = match['match_confidence']
        
        y = 90 + ((i - start_idx) * 55)  # Increased from 40 to 55 for better separation between two-line entries
        
        # Add selection indicator for selected item (no background rectangles)
        if i == selected_position:
            # Add selection arrow
            gr.draw_text((42, y+2), ">", font=11, color='white')
            text_x = 60
        else:
            # No background, just text
            text_x = 50
        
        # Game name (truncate if too long)
        game_name = game_data.game_name
        if len(game_name) > 35:
            game_name = game_name[:32] + "..."
        gr.draw_text((text_x, y+2), game_name, font=11, color='white')
        
        # System and confidence in a compact format
        system_conf_text = f"[{rom_info['system']}] {confidence:.0%}"
        gr.draw_text((text_x, y+14), system_conf_text, font=11, color='lightblue')
        
        # Completion times (right side)
        time_x = 450
        if hasattr(game_data, 'main_story') and game_data.main_story:
            main_time = game_search_manager.format_time(game_data.main_story)
            gr.draw_text((time_x, y+2), f"Main: {main_time}", font=11, color='lightblue')
            
            if hasattr(game_data, 'completionist') and game_data.completionist:
                comp_time = game_search_manager.format_time(game_data.completionist)
                gr.draw_text((time_x, y+14), f"100%: {comp_time}", font=11, color='lightblue')
        else:
            gr.draw_text((time_x, y+8), "No time data", font=11, color='lightblue')
    
    # Enhanced control instructions
    gr.draw_text((50, 410), "Controls:", font=11, color='lightblue')
    gr.draw_text((50, 430), "Up/Down - Nav", font=11, color='lightblue')
    gr.draw_text((200, 430), "A - View", font=11, color='lightblue')
    gr.draw_text((450, 430), "B - Back", font=11, color='lightblue')
    
    # Summary stats at the bottom
    total_main_time = 0
    total_comp_time = 0
    games_with_data = 0
    
    for match in rom_scan_results:
        game_data = match['game_data']
        if hasattr(game_data, 'main_story') and game_data.main_story:
            total_main_time += game_data.main_story
            games_with_data += 1
        if hasattr(game_data, 'completionist') and game_data.completionist:
            total_comp_time += game_data.completionist
    
    if games_with_data > 0:
        stats_text = f"Collection Stats: {games_with_data} games"
        gr.draw_text((50, 460), stats_text, font=11, color='lightblue')
        
        if total_main_time > 0:
            total_main_formatted = game_search_manager.format_time(total_main_time)
            main_stats = f"  | Total time: {total_main_formatted}"
            gr.draw_text((300, 460), main_stats, font=11, color='lightblue')

def load_menu_screen():
    gr.draw_clear()
    
    
    # Menu options
    for i, option in enumerate(menu_options):
        y = 180 + (i * 50)
        
        # Show selection with text indicator only (no background rectangles)
        if i == menu_selected:
            gr.draw_text((50, y+5), f"> {option}", font=13, color='lightblue')
        else:
            gr.draw_text((60, y+5), option, font=13, color='lightblue')
    
    # Version info
    gr.draw_text((50, 450), "How Long to Beat v1.0 - Scanner & Game Search", font=11, color='lightblue')

if __name__ == "__main__":
    try:
        start()
        while True:
            result = update()
            if result == "exit":
                break
    except KeyboardInterrupt:
        print("\nExiting Game Search gracefully...")
        exit_handler()
        sys.exit(0)
    except Exception as e:
        print(f"Unexpected error in Game Search: {str(e)}")
        exit_handler()
        sys.exit(1) 
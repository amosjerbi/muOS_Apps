#!/bin/sh
# Dependency installation script for How Long to Beat Game Search

# Log file
LOG_FILE="$(dirname "$0")/howlongtobeat.log"
echo "Running dependency installation script at $(date)" >> "$LOG_FILE"

# Function to log messages
log_message() {
    echo "$1" >> "$LOG_FILE"
    echo "$1"
}

# Install pip if not available
if ! command -v pip3 >/dev/null 2>&1; then
    log_message "Installing pip..."
    python3 -m ensurepip --user >> "$LOG_FILE" 2>&1
    
    # Add pip to PATH
    export PATH="/root/.local/bin:$PATH"
    echo 'export PATH="/root/.local/bin:$PATH"' >> /root/.bashrc
    
    log_message "Pip installed successfully"
else
    log_message "Pip is already installed"
fi

# Install PIL if not available
if ! python3 -c "import PIL" >/dev/null 2>&1; then
    log_message "Installing PIL (Pillow)..."
    export PATH="/root/.local/bin:$PATH"
    python3 -m pip install pillow >> "$LOG_FILE" 2>&1
    
    # Check if installation was successful
    if python3 -c "import PIL" >/dev/null 2>&1; then
        log_message "PIL installed successfully"
    else
        log_message "ERROR: Failed to install PIL"
        exit 1
    fi
else
    log_message "PIL is already installed"
fi

# Install howlongtobeatpy (required for game search functionality)
if ! python3 -c "import howlongtobeatpy" >/dev/null 2>&1; then
    log_message "Installing howlongtobeatpy for game search functionality..."
    export PATH="/root/.local/bin:$PATH"
    python3 -m pip install howlongtobeatpy >> "$LOG_FILE" 2>&1
    
    # Check if installation was successful
    if python3 -c "import howlongtobeatpy" >/dev/null 2>&1; then
        log_message "howlongtobeatpy installed successfully"
    else
        log_message "ERROR: Failed to install howlongtobeatpy. Game search will not work."
        exit 1
    fi
else
    log_message "howlongtobeatpy is already installed"
fi

log_message "How Long to Beat dependencies installation completed!"
exit 0

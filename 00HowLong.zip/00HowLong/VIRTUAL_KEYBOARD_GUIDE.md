# Virtual Keyboard Guide - WiFi Manager

## Overview

The WiFi Manager now includes a full virtual keyboard system that allows you to edit SSID and PSK (password) values directly on the device using the handheld controls. This feature was adapted from the original ROM Downloader's keyboard implementation.

## Features

- **Edit existing networks**: Modify SSID, password, and priority of saved networks
- **Add new networks**: Create new WiFi configurations from scratch
- **Delete networks**: Remove unwanted network configurations
- **Virtual keyboard**: Full QWERTY layout with numbers and special characters
- **Password masking**: PSK fields are displayed as asterisks for security
- **Priority management**: Set connection priority for networks

## Controls

### Main Menu Navigation
- **D-Pad Up/Down**: Navigate through saved networks
- **A Button**: Connect to selected network
- **B Button**: Refresh network list
- **X Button**: Edit selected network
- **Y Button**: Add new network
- **L1 Button**: Delete selected network
- **M Button**: Exit application

### Edit Screen Navigation
- **D-Pad Up/Down**: Navigate between fields (SSID → Password → Priority)
- **A Button**: Open virtual keyboard for selected field
- **B Button**: Cancel editing and return to main menu

### Virtual Keyboard Navigation
- **D-Pad**: Navigate through keyboard keys
- **A Button**: Select key or special function
- **Special Keys**:
  - **DEL**: Delete last character
  - **CLEAR**: Clear entire field
  - **SAVE**: Save network and return to main menu
  - **CANCEL**: Cancel editing and return to edit screen

## Virtual Keyboard Layout

```
Numbers:  [1] [2] [3] [4] [5] [6] [7] [8] [9] [0]
Row 1:    [q] [w] [e] [r] [t] [y] [u] [i] [o] [p]
Row 2:    [a] [s] [d] [f] [g] [h] [j] [k] [l] [-]
Row 3:    [z] [x] [c] [v] [b] [n] [m] [_] [.] [ ]

Special:  [DEL] [CLEAR] [SAVE] [CANCEL]
```

## Usage Examples

### Adding a New Network

1. From main menu, press **Y** to add new network
2. Use **D-Pad Up/Down** to select SSID field
3. Press **A** to open virtual keyboard
4. Type the network name using D-Pad and A button
5. Press **A** on **SAVE** when done with SSID
6. Navigate to Password field and repeat
7. Set Priority if needed (default is 1)
8. Press **A** on **SAVE** to save the network

### Editing an Existing Network

1. From main menu, use **D-Pad** to select network
2. Press **X** to edit selected network
3. Navigate to field you want to change
4. Press **A** to open virtual keyboard
5. Use **CLEAR** to erase current value if needed
6. Type new value
7. Press **A** on **SAVE** to save changes

### Deleting a Network

1. From main menu, use **D-Pad** to select network
2. Press **L1** to delete
3. Confirm deletion (network is immediately removed)

## Field Descriptions

### SSID (Network Name)
- The name of the WiFi network as it appears in network lists
- Case-sensitive
- Can contain letters, numbers, spaces, and special characters

### PSK (Password)
- The WiFi network password
- Displayed as asterisks (*) for security
- Can contain any characters supported by the keyboard

### Priority
- Numeric value determining connection preference
- Higher numbers = higher priority
- When multiple networks are available, device connects to highest priority
- Range: 1-999 (typically 1-10 is sufficient)

## Technical Details

### File Operations
- **Local Config**: Uses `./wpa_supplicant.conf` if present
- **System Config**: Falls back to `/etc/wpa_supplicant.conf`
- **Auto-backup**: Original system config is preserved
- **Priority Management**: Automatically adjusts priorities to avoid conflicts

### Network Management
- **Add Network**: Appends new network block to config file
- **Update Network**: Uses regex pattern matching to replace existing blocks
- **Delete Network**: Removes entire network block from config
- **Validation**: Checks for valid SSID and priority values

### Connection Process
- **Smart Priority**: Temporarily boosts target network priority
- **System Integration**: Works with wpa_supplicant daemon
- **Status Detection**: Uses `iw dev wlan0 link` for connection status
- **Fallback**: Restores original priorities after connection

## Troubleshooting

### Common Issues

**Keyboard not responding**:
- Ensure you're in keyboard mode (screen shows virtual keyboard)
- Try pressing different D-Pad directions to verify navigation

**Can't save network**:
- Check that SSID field is not empty
- Verify priority is a valid number (1-999)
- Ensure you have write permissions to config file

**Network not connecting**:
- Verify SSID and password are correct
- Check that network is in range
- Try refreshing network list with B button

**Priority conflicts**:
- System automatically adjusts priorities to avoid conflicts
- Higher numbers take precedence
- Use manage_wifi.py script for manual priority management

### Debug Information

The application prints debug information to console:
- Network parsing results
- Connection attempts
- File operations
- Error messages

### File Locations

- **Local Config**: `./wpa_supplicant.conf`
- **System Config**: `/etc/wpa_supplicant.conf`
- **Management Script**: `./manage_wifi.py`
- **Documentation**: `./LOCAL_CONFIG_README.md`

## Advanced Usage

### Using Management Script

```bash
# View current networks
python3 manage_wifi.py

# Add network via script
python3 manage_wifi.py --add "NetworkName" "password123" 5

# Remove network via script
python3 manage_wifi.py --remove "NetworkName"
```

### Manual Config Editing

You can also edit `wpa_supplicant.conf` directly:

```
network={
    ssid="YourNetwork"
    psk="YourPassword"
    priority=5
}
```

## Security Notes

- Passwords are stored in plain text in wpa_supplicant.conf
- Local config file should have restricted permissions (600)
- Virtual keyboard masks password display but doesn't encrypt storage
- Consider using WPA Enterprise for sensitive environments

## Compatibility

- **muOS Devices**: Primary target platform
- **Linux Systems**: Compatible with standard wpa_supplicant
- **Input Methods**: Designed for handheld gaming device controls
- **Display**: Optimized for 720x480 resolution

This virtual keyboard system provides a complete solution for managing WiFi networks directly on the device without requiring external tools or SSH access. 
import graphic as gr
from graphic import set_resolution_720x480
import input
import sys
import time

# Global variables
keyboard_position = [0, 0]
search_query = ""

virtual_keyboard = [
    ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
    ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
    ["a", "s", "d", "f", "g", "h", "j", "k", "l", "-"],
    ["z", "x", "c", "v", "b", "n", "m", "_", ".", " "]
]

def load_keyboard_screen():
    gr.draw_clear()
    
    # Title
    gr.draw_text((50, 30), "KEYBOARD TEST - Press M to exit", font=15, color='white')
    
    # Current input
    gr.draw_rectangle([40, 60, 600, 90], fill='darkblue', outline='blue')
    gr.draw_text((50, 70), search_query + "_", font=13, color='white')
    
    # Virtual keyboard
    start_y = 130
    for row_idx, row in enumerate(virtual_keyboard):
        y = start_y + (row_idx * 40)
        for col_idx, key in enumerate(row):
            x = 50 + (col_idx * 55)
            
            # Highlight selected key
            if keyboard_position[1] == row_idx and keyboard_position[0] == col_idx:
                gr.draw_rectangle([x-2, y-2, x+48, y+32], fill=gr.colorBlue, outline='white')
            else:
                gr.draw_rectangle([x-2, y-2, x+48, y+32], fill='gray', outline='lightgray')
            
            gr.draw_text((x+15, y+8), key, font=11, color='white')
    
    # Controls and current position info
    gr.draw_text((50, 320), "A - Select, Arrows - Navigate, M - Exit", font=11, color='yellow')
    gr.draw_text((50, 340), f"Position: [{keyboard_position[0]}, {keyboard_position[1]}]", font=11, color='cyan')

def main():
    global keyboard_position, search_query
    
    print("Starting keyboard test...")
    gr.draw_start()
    print("Graphics initialized, showing keyboard...")
    
    skip_input_check = False
    
    while True:
        try:
            if skip_input_check:
                input.reset_input()
                skip_input_check = False
            else:
                input.check()

            # Exit handling
            if input.key("MENUF") or input.codeName == "M":
                print("Exit pressed, closing...")
                break

            # Navigation
            if input.key("DY", -1):  # Up
                if keyboard_position[1] > 0:
                    keyboard_position[1] -= 1
                    print(f"Moved up to {keyboard_position}")
                skip_input_check = True
                
            elif input.key("DY", 1):  # Down
                if keyboard_position[1] < len(virtual_keyboard) - 1:
                    keyboard_position[1] += 1
                    print(f"Moved down to {keyboard_position}")
                skip_input_check = True
                
            elif input.key("DX", -1):  # Left
                if keyboard_position[0] > 0:
                    keyboard_position[0] -= 1
                    print(f"Moved left to {keyboard_position}")
                skip_input_check = True
                
            elif input.key("DX", 1):  # Right
                if keyboard_position[0] < len(virtual_keyboard[keyboard_position[1]]) - 1:
                    keyboard_position[0] += 1
                    print(f"Moved right to {keyboard_position}")
                skip_input_check = True
                
            elif input.key("A"):  # Select character
                char = virtual_keyboard[keyboard_position[1]][keyboard_position[0]]
                search_query += char
                print(f"Selected: {char}, query now: {search_query}")
                skip_input_check = True

            load_keyboard_screen()
            gr.draw_paint()
            time.sleep(0.05)

        except Exception as e:
            print(f"Error: {str(e)}")
            break

    # Clean up
    print("Cleaning up...")
    set_resolution_720x480()
    gr.draw_end()

if __name__ == "__main__":
    main() 
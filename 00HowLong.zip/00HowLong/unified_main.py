import graphic as gr
from graphic import set_resolution_720x480
import input
import sys
import time
import os
import atexit
import signal
import subprocess
import traceback

# Global flag to prevent duplicate exit handling
_exit_handler_called = False

# Exit handler to ensure resolution is reset on exit
def exit_handler():
    global _exit_handler_called
    if _exit_handler_called:
        return
    _exit_handler_called = True
    
    print("Exiting Unified Manager, resetting resolution to 720x480...")
    try:
        set_resolution_720x480()
        gr.draw_end()
    except Exception as e:
        print(f"Error in exit handler: {str(e)}")

# Signal handler for graceful termination
def signal_handler(sig, frame):
    print(f"Received signal {sig}, exiting gracefully...")
    exit_handler()
    sys.exit(0)

# Register the exit handler
atexit.register(exit_handler)

# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Global variables
selected_position = 0
current_window = "menu"
skip_input_check = False
feedback_message = ""
feedback_timer = 0

menu_options = [
    {"name": "How Long to Beat", "description": "Search game completion times", "script": "game_search_main.py"},
    {"name": "Game Search Test", "description": "Test game search functionality", "script": "test_game_search.py"}
]

def start():
    # Initialize graphics system
    gr.draw_start()
    load_menu_screen()

def update():
    try:
        global current_window, skip_input_check, feedback_timer, selected_position

        if skip_input_check:
            input.reset_input()
            skip_input_check = False
        else:
            input.check()

        # Decrease feedback timer
        if feedback_timer > 0:
            feedback_timer -= 1

        # Exit handling
        if input.key("MENUF") or input.codeName == "M" or input.codeName == "312":
            print("Exit button pressed, exiting Unified Manager...")
            exit_handler()
            return "exit"

        # Handle menu navigation with bounds checking
        if input.key("DY", -1):  # Up
            if selected_position > 0:
                selected_position -= 1
            else:
                selected_position = len(menu_options) - 1  # Wrap to bottom
            skip_input_check = True
            
        elif input.key("DY", 1):  # Down
            if selected_position < len(menu_options) - 1:
                selected_position += 1
            else:
                selected_position = 0  # Wrap to top
            skip_input_check = True
            
        elif input.key("A"):  # Launch selected application
            if 0 <= selected_position < len(menu_options):
                launch_application(selected_position)
            skip_input_check = True
            
        elif input.key("B"):  # Exit
            exit_handler()
            return "exit"

        # Refresh the display
        load_menu_screen()
        gr.draw_paint()
        time.sleep(0.05)  # 50ms delay for smooth operation

    except Exception as e:
        print(f"Error in unified main update: {str(e)}")
        traceback.print_exc()
        return "error"

def launch_application(index):
    global feedback_message, feedback_timer
    
    if index < 0 or index >= len(menu_options):
        feedback_message = "Invalid selection"
        feedback_timer = 60
        return
        
    option = menu_options[index]
    
    try:
        # Check if the script exists
        if not os.path.exists(option["script"]):
            feedback_message = f"Error: {option['script']} not found!"
            feedback_timer = 120
            print(f"Script not found: {option['script']}")
            return
            
        # Launch the application and exit this menu
        feedback_message = f"Launching {option['name']}..."
        feedback_timer = 60
        
        print(f"Launching {option['name']} with script: {option['script']}")
        
        # Exit the menu and launch the app directly
        exit_handler()
        os.execv(sys.executable, [sys.executable, option["script"]])
        
    except Exception as e:
        feedback_message = f"Error launching {option['name']}: {str(e)}"
        feedback_timer = 120
        print(f"Launch error: {str(e)}")
        traceback.print_exc()

def load_menu_screen():
    try:
        # Ensure selected position is within bounds
        global selected_position
        if selected_position < 0:
            selected_position = 0
        elif selected_position >= len(menu_options):
            selected_position = len(menu_options) - 1
            
        gr.draw_clear()
        
        # Title
        gr.draw_text((320, 40), "How Long to Beat Game Search", anchor="mm", font=15, color='white')
        gr.draw_text((320, 70), "Choose an option:", anchor="mm", font=13, color='lightgray')
        
        # Menu options
        start_y = 140  # Moved down slightly for better spacing
        for i, option in enumerate(menu_options):
            y = start_y + (i * 80)  # Increased spacing between options
            
            # Highlight selected option
            if i == selected_position:
                gr.draw_rectangle_r([50, y-15, 590, y+50], 10, fill=gr.colorBlue, outline='white')
                text_color = 'white'
                desc_color = 'lightcyan'
            else:
                gr.draw_rectangle_r([50, y-15, 590, y+50], 10, fill=gr.colorGray, outline='lightgray')
                text_color = 'lightgray'
                desc_color = 'gray'
            
            # Option name
            gr.draw_text((70, y), option["name"], font=15, color=text_color, anchor="lm")
            
            # Option description
            gr.draw_text((70, y+25), option["description"], font=11, color=desc_color, anchor="lm")
        
        # Instructions
        gr.draw_text((320, 340), "Controls:", anchor="mm", font=13, color='yellow')
        gr.draw_text((320, 365), "Up/Down - Navigate, A - Launch, B/M - Exit", anchor="mm", font=11, color='white')
        
        # Feedback message
        if feedback_timer > 0 and feedback_message:
            gr.draw_rectangle_r([100, 390, 540, 420], 5, fill='darkblue', outline='blue')
            gr.draw_text((320, 405), feedback_message, anchor="mm", font=11, color='white')
        
        # Footer
        gr.draw_text((320, 450), "How Long to Beat Game Search v1.0", anchor="mm", font=11, color='darkgray')
        
    except Exception as e:
        print(f"Error in load_menu_screen: {str(e)}")
        traceback.print_exc()
        # Draw a simple error message
        gr.draw_clear()
        gr.draw_text((320, 240), "Menu Error - Press M to exit", anchor="mm", font=15, color='red')

def main():
    try:
        start()

        while True:
            try:
                result = update()
                if result == "exit":
                    break
            except Exception as e:
                print(f"Error in main loop: {str(e)}")
                traceback.print_exc()
                # Don't exit, continue running
                continue
    except Exception as e:
        print(f"Fatal error: {str(e)}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExiting gracefully...")
        exit_handler()
        sys.exit(0)
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        traceback.print_exc()
        exit_handler()
        sys.exit(1) 
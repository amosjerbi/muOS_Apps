# Local WiFi Configuration Override

The WiFi Manager now supports using a local `wpa_supplicant.conf` file that overrides the system configuration. This is perfect for testing, development, and managing WiFi networks without modifying the system files.

## How It Works

1. **Priority**: If a `./wpa_supplicant.conf` file exists in the application directory, it will be used instead of `/etc/wpa_supplicant.conf`
2. **Display**: The WiFi Manager will show networks from the local config
3. **Connection**: When connecting, the selected network is temporarily copied to the system config for actual connection
4. **Restoration**: The system config is automatically restored after connection attempts

## Benefits

- ✅ **Safe Testing**: Test different network configurations without affecting system settings
- ✅ **Easy Management**: Add/remove networks for testing without root access to system files
- ✅ **Development**: Perfect for developing and debugging WiFi functionality
- ✅ **Backup**: Keep your test configurations separate from production

## Usage

### Using the Management Script

```bash
# Show current configuration status
python3 manage_wifi.py status

# Add a new test network
python3 manage_wifi.py add "MyTestNetwork" "password123" 5

# Copy system config to local for editing
python3 manage_wifi.py copy

# Edit the local config file
python3 manage_wifi.py edit

# Remove local config (use system config)
python3 manage_wifi.py remove
```

### Manual Configuration

Create a `wpa_supplicant.conf` file in the application directory:

```bash
# Local wpa_supplicant.conf for testing WiFi Manager
# Higher priority numbers are preferred

network={
    ssid="TestNetwork1"
    scan_ssid=1
    psk="password123"
    priority=5
}

network={
    ssid="TestNetwork2"
    scan_ssid=1
    psk="password456"
    priority=3
}
```

## File Locations

- **Local Config**: `./wpa_supplicant.conf` (in application directory)
- **System Config**: `/etc/wpa_supplicant.conf` (system-wide)
- **Backup**: `/etc/wpa_supplicant.conf.backup` (created during connections)

## Connection Process

When connecting to a network from local config:

1. The target network block is extracted from local config
2. System config is backed up
3. Network is temporarily added to system config with highest priority
4. wpa_supplicant is restarted with system config
5. Connection attempt is made
6. System config is restored to original state

## Examples

### Testing New Networks

```bash
# Add a test network
python3 manage_wifi.py add "CoffeeShop" "freewifi" 2

# Check status
python3 manage_wifi.py status

# Test connection in WiFi Manager
python3 main.py
```

### Development Workflow

```bash
# Copy current system config for testing
python3 manage_wifi.py copy

# Edit and add test networks
python3 manage_wifi.py edit

# Test in WiFi Manager
python3 main.py

# Remove local config when done
python3 manage_wifi.py remove
```

## Troubleshooting

### Local Config Not Being Used

- Check that `wpa_supplicant.conf` exists in the application directory
- Verify file permissions are readable
- Check the console output for "Using local wpa_supplicant.conf" message

### Connection Issues

- Ensure the network exists in local config
- Check that passwords are correct
- Verify the system has write access to `/etc/wpa_supplicant.conf`
- Check that wpa_supplicant service can be restarted

### Restoring System Config

If something goes wrong, you can manually restore:

```bash
# If backup exists
cp /etc/wpa_supplicant.conf.backup /etc/wpa_supplicant.conf

# Or remove local config to use system
rm ./wpa_supplicant.conf
```

## Security Notes

- Local config files may contain WiFi passwords in plain text
- Ensure proper file permissions (readable only by authorized users)
- Local configs are temporary and for testing - don't store production passwords
- System config is automatically backed up before modifications 